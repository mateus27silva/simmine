import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const projects = await db.project.findMany({
      orderBy: {
        updatedAt: 'desc'
      },
      include: {
        unitOperations: true,
        streams: true,
        simulationLogs: {
          orderBy: {
            timestamp: 'desc'
          },
          take: 5
        }
      }
    })

    return NextResponse.json(projects)

  } catch (error) {
    console.error('Error fetching projects:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar projetos' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, flowsheet } = body

    if (!name) {
      return NextResponse.json(
        { error: 'Nome do projeto é obrigatório' },
        { status: 400 }
      )
    }

    const project = await db.project.create({
      data: {
        name,
        description,
        flowsheet: flowsheet ? JSON.stringify(flowsheet) : '{}'
      },
      include: {
        unitOperations: true,
        streams: true,
        simulationLogs: {
          orderBy: {
            timestamp: 'desc'
          },
          take: 5
        }
      }
    })

    // Log project creation
    await db.simulationLog.create({
      data: {
        type: 'ACTION',
        message: `Projeto criado: ${name}`,
        projectId: project.id,
        details: JSON.stringify({ action: 'project_created' })
      }
    })

    return NextResponse.json(project)

  } catch (error) {
    console.error('Error creating project:', error)
    return NextResponse.json(
      { error: 'Erro ao criar projeto' },
      { status: 500 }
    )
  }
}