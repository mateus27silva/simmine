'use client'

import { useState } from 'react'
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable'
import { Sidebar } from '@/components/mineral-processing/sidebar'
import { Flowsheet } from '@/components/mineral-processing/flowsheet'
import { PropertiesPanel } from '@/components/mineral-processing/properties-panel'
import { Toolbar } from '@/components/mineral-processing/toolbar'
import { ResultsPanel } from '@/components/mineral-processing/results-panel'
import { ActionLog } from '@/components/mineral-processing/action-log'
import { SimulationProgress } from '@/components/mineral-processing/simulation-progress'

export default function Home() {
  const [selectedUnit, setSelectedUnit] = useState<string | null>(null)
  const [simulationData, setSimulationData] = useState<any>({})
  const [units, setUnits] = useState<any[]>([])
  const [streams, setStreams] = useState<any[]>([])
  const [logRefreshTrigger, setLogRefreshTrigger] = useState(0)

  return (
    <div className="flex flex-col h-screen bg-background">
      <Toolbar 
        onSimulationRun={() => setLogRefreshTrigger(prev => prev + 1)}
        units={units}
        streams={streams}
      />
      
      <ResizablePanelGroup direction="horizontal" className="flex-1">
        <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
          <Sidebar />
        </ResizablePanel>
        
        <ResizableHandle withHandle />
        
        <ResizablePanel defaultSize={80} minSize={70}>
          <Flowsheet 
            selectedUnit={selectedUnit}
            setSelectedUnit={setSelectedUnit}
            simulationData={simulationData}
            setSimulationData={setSimulationData}
            onUnitsChange={setUnits}
            onStreamsChange={setStreams}
          />
        </ResizablePanel>
      </ResizablePanelGroup>
      
      <ResultsPanel simulationData={simulationData} />
      
      {/* Action Log Panel - Below results */}
      <div className="h-48 border-t bg-background">
        <ActionLog refreshTrigger={logRefreshTrigger} />
      </div>
    </div>
  )
}