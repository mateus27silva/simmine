import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { projectId, format = 'json' } = await request.json()

    // Get project data
    const project = projectId ? await db.project.findUnique({
      where: { id: projectId },
      include: {
        unitOperations: true,
        streams: true,
        simulationResults: true,
        simulationLogs: {
          orderBy: { timestamp: 'desc' },
          take: 100
        }
      }
    }) : null

    if (!project) {
      // If no project ID, export current session data
      const body = await request.json()
      const { units, streams, results } = body
      
      return generateExport(units, streams, results, [], format)
    }

    return generateExport(
      project.unitOperations,
      project.streams,
      project.simulationResults,
      project.simulationLogs,
      format
    )

  } catch (error) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'Erro ao exportar dados' },
      { status: 500 }
    )
  }
}

async function generateExport(
  units: any[],
  streams: any[],
  results: any[],
  logs: any[],
  format: string
) {
  const exportData = {
    metadata: {
      exportDate: new Date().toISOString(),
      version: '1.0.0',
      format: format
    },
    summary: {
      totalUnits: units.length,
      totalStreams: streams.length,
      totalResults: results.length,
      totalLogs: logs.length
    },
    units: units.map(unit => ({
      id: unit.id,
      type: unit.type,
      name: unit.name,
      position: { x: unit.x, y: unit.y },
      parameters: typeof unit.parameters === 'string' ? JSON.parse(unit.parameters) : unit.parameters,
      inputs: typeof unit.inputs === 'string' ? JSON.parse(unit.inputs) : unit.inputs,
      outputs: typeof unit.outputs === 'string' ? JSON.parse(unit.outputs) : unit.outputs
    })),
    streams: streams.map(stream => ({
      id: stream.id,
      from: stream.fromUnit,
      to: stream.toUnit,
      flowRate: stream.flowRate,
      composition: typeof stream.composition === 'string' ? JSON.parse(stream.composition) : stream.composition,
      moisture: stream.moisture,
      temperature: stream.temperature,
      pressure: stream.pressure
    })),
    results: results.map(result => ({
      unitOperation: result.unitOperation,
      streamId: result.streamId,
      parameter: result.parameter,
      value: result.value,
      unit: result.unit,
      timestamp: result.timestamp
    })),
    logs: logs.map(log => ({
      type: log.type,
      message: log.message,
      details: log.details ? JSON.parse(log.details) : null,
      timestamp: log.timestamp
    }))
  }

  switch (format) {
    case 'json':
      return NextResponse.json(exportData, {
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="simulation-export-${Date.now()}.json"`
        }
      })

    case 'csv':
      const csvContent = generateCSV(exportData)
      return new NextResponse(csvContent, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="simulation-export-${Date.now()}.csv"`
        }
      })

    case 'txt':
      const txtContent = generateTXT(exportData)
      return new NextResponse(txtContent, {
        headers: {
          'Content-Type': 'text/plain',
          'Content-Disposition': `attachment; filename="simulation-report-${Date.now()}.txt"`
        }
      })

    default:
      return NextResponse.json(exportData)
  }
}

function generateCSV(data: any): string {
  let csv = 'Type,ID,Parameter,Value,Unit,Timestamp\n'
  
  // Add units
  data.units.forEach((unit: any) => {
    csv += `Unit,${unit.id},Type,${unit.type},,\n`
    csv += `Unit,${unit.id},Name,${unit.name},,\n`
    Object.entries(unit.parameters).forEach(([key, value]) => {
      csv += `Unit,${unit.id},${key},${value},,\n`
    })
  })

  // Add streams
  data.streams.forEach((stream: any) => {
    csv += `Stream,${stream.id},Flow Rate,${stream.flowRate},t/h,\n`
    csv += `Stream,${stream.id},Moisture,${stream.moisture},%,\n`
    Object.entries(stream.composition).forEach(([component, value]) => {
      csv += `Stream,${stream.id},${component} Flow,${value},t/h,\n`
    })
  })

  // Add results
  data.results.forEach((result: any) => {
    csv += `Result,${result.unitOperation || result.streamId},${result.parameter},${result.value},${result.unit || ''},${result.timestamp}\n`
  })

  return csv
}

function generateTXT(data: any): string {
  let txt = `RELATÓRIO DE SIMULAÇÃO - BALANÇO DE MASSA\n`
  txt += `===========================================\n\n`
  txt += `Data de Exportação: ${new Date(data.metadata.exportDate).toLocaleString('pt-BR')}\n`
  txt += `Versão: ${data.metadata.version}\n\n`

  txt += `RESUMO\n`
  txt += `------\n`
  txt += `Total de Unidades: ${data.summary.totalUnits}\n`
  txt += `Total de Correntes: ${data.summary.totalStreams}\n`
  txt += `Total de Resultados: ${data.summary.totalResults}\n`
  txt += `Total de Logs: ${data.summary.totalLogs}\n\n`

  if (data.units.length > 0) {
    txt += `UNIDADES OPERACIONAIS\n`
    txt += `---------------------\n`
    data.units.forEach((unit: any) => {
      txt += `\n${unit.name} (${unit.type})\n`
      txt += `ID: ${unit.id}\n`
      txt += `Posição: (${unit.x}, ${unit.y})\n`
      txt += `Parâmetros:\n`
      Object.entries(unit.parameters).forEach(([key, value]) => {
        txt += `  - ${key}: ${value}\n`
      })
    })
    txt += `\n`
  }

  if (data.streams.length > 0) {
    txt += `CORRENTES\n`
    txt += `---------\n`
    data.streams.forEach((stream: any) => {
      txt += `\nCorrente ${stream.id}\n`
      txt += `De: ${stream.from} → Para: ${stream.to}\n`
      txt += `Vazão: ${stream.flowRate} t/h\n`
      txt += `Umidade: ${stream.moisture}%\n`
      txt += `Composição:\n`
      Object.entries(stream.composition).forEach(([component, value]) => {
        txt += `  - ${component}: ${(value as number * 100).toFixed(1)}%\n`
      })
    })
    txt += `\n`
  }

  if (data.results.length > 0) {
    txt += `RESULTADOS DA SIMULAÇÃO\n`
    txt += `------------------------\n`
    data.results.forEach((result: any) => {
      txt += `${result.parameter}: ${result.value} ${result.unit || ''}`
      if (result.unitOperation) txt += ` (Unidade: ${result.unitOperation})`
      if (result.streamId) txt += ` (Corrente: ${result.streamId})`
      txt += `\n`
    })
    txt += `\n`
  }

  if (data.logs.length > 0) {
    txt += `REGISTRO DE AÇÕES\n`
    txt += `-----------------\n`
    data.logs.slice(0, 20).forEach((log: any) => {
      const timestamp = new Date(log.timestamp).toLocaleString('pt-BR')
      txt += `[${timestamp}] ${log.type}: ${log.message}\n`
    })
    if (data.logs.length > 20) {
      txt += `... e mais ${data.logs.length - 20} logs\n`
    }
  }

  return txt
}