import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Simulate running simulations with progress tracking
const runningSimulations = new Map<string, {
  startTime: Date
  progress: number
  status: 'running' | 'completed' | 'error'
  message: string
  results?: any
}>()

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const simulationId = searchParams.get('simulationId')

    if (simulationId && runningSimulations.has(simulationId)) {
      const simulation = runningSimulations.get(simulationId)!
      return NextResponse.json({
        simulationId,
        status: simulation.status,
        progress: simulation.progress,
        message: simulation.message,
        results: simulation.results,
        startTime: simulation.startTime
      })
    }

    // Get recent simulation logs as status
    const recentLogs = await db.simulationLog.findMany({
      where: {
        type: { in: ['EXECUTION', 'ERROR'] }
      },
      orderBy: { timestamp: 'desc' },
      take: 10
    })

    const status = {
      isRunning: runningSimulations.size > 0,
      runningCount: runningSimulations.size,
      recentActivities: recentLogs.map(log => ({
        id: log.id,
        type: log.type,
        message: log.message,
        timestamp: log.timestamp,
        details: log.details ? JSON.parse(log.details) : null
      }))
    }

    return NextResponse.json(status)
  } catch (error) {
    console.error('Error fetching simulation status:', error)
    return NextResponse.json({ error: 'Erro ao buscar status da simulação' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { simulationId, action } = await request.json()

    if (action === 'start') {
      const id = simulationId || `sim-${Date.now()}`
      
      runningSimulations.set(id, {
        startTime: new Date(),
        progress: 0,
        status: 'running',
        message: 'Iniciando simulação...'
      })

      // Simulate progress updates
      simulateProgress(id)

      return NextResponse.json({ 
        simulationId: id, 
        message: 'Simulação iniciada' 
      })
    }

    if (action === 'stop' && simulationId) {
      const simulation = runningSimulations.get(simulationId)
      if (simulation) {
        simulation.status = 'error'
        simulation.message = 'Simulação interrompida pelo usuário'
        simulation.progress = 0
        
        return NextResponse.json({ 
          simulationId, 
          message: 'Simulação interrompida' 
        })
      }
    }

    return NextResponse.json({ error: 'Ação inválida' }, { status: 400 })
  } catch (error) {
    console.error('Error updating simulation status:', error)
    return NextResponse.json({ error: 'Erro ao atualizar status' }, { status: 500 })
  }
}

function simulateProgress(simulationId: string) {
  const simulation = runningSimulations.get(simulationId)
  if (!simulation) return

  const steps = [
    { progress: 10, message: 'Validando dados de entrada...' },
    { progress: 25, message: 'Calculando balanço de massa...' },
    { progress: 50, message: 'Processando unidades operacionais...' },
    { progress: 75, message: 'Analisando resultados...' },
    { progress: 90, message: 'Finalizando cálculos...' },
    { progress: 100, message: 'Simulação concluída!' }
  ]

  let currentStep = 0

  const updateProgress = () => {
    const simulation = runningSimulations.get(simulationId)
    if (!simulation || simulation.status !== 'running') return

    if (currentStep < steps.length) {
      const step = steps[currentStep]
      simulation.progress = step.progress
      simulation.message = step.message
      currentStep++

      setTimeout(updateProgress, 1000 + Math.random() * 2000) // Random delay between steps
    } else {
      simulation.status = 'completed'
      simulation.progress = 100
      simulation.message = 'Simulação concluída com sucesso!'
      simulation.results = {
        summary: {
          totalUnits: Math.floor(Math.random() * 10) + 5,
          totalStreams: Math.floor(Math.random() * 15) + 8,
          executionTime: Math.floor(Math.random() * 5000) + 2000,
          massBalanceError: (Math.random() * 2).toFixed(3)
        }
      }

      // Clean up old simulations
      setTimeout(() => {
        runningSimulations.delete(simulationId)
      }, 30000) // Keep for 30 seconds
    }
  }

  // Start progress simulation
  setTimeout(updateProgress, 500)
}