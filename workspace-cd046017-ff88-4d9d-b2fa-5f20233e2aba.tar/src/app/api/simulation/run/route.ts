import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { units, streams, projectId } = await request.json()
    
    // Log the start of simulation
    await db.simulationLog.create({
      data: {
        projectId,
        type: 'EXECUTION',
        message: 'Iniciando simulação de balanço de massa',
        details: JSON.stringify({ unitsCount: units?.length || 0, streamsCount: streams?.length || 0 })
      }
    })

    // Validate inputs
    if (!units || !Array.isArray(units)) {
      await db.simulationLog.create({
        data: {
          projectId,
          type: 'ERROR',
          message: 'Unidades operacionais inválidas ou ausentes',
          details: JSON.stringify({ error: 'Invalid units data' })
        }
      })
      return NextResponse.json({ error: 'Unidades operacionais inválidas' }, { status: 400 })
    }

    // Perform mass balance calculations
    const results = await performMassBalanceCalculation(units, streams, projectId)
    
    // Log successful completion
    await db.simulationLog.create({
      data: {
        projectId,
        type: 'EXECUTION',
        message: 'Simulação concluída com sucesso',
        details: JSON.stringify({ resultsCount: results.length })
      }
    })

    return NextResponse.json({ 
      success: true, 
      results,
      message: 'Simulação executada com sucesso' 
    })
  } catch (error) {
    console.error('Simulation error:', error)
    
    await db.simulationLog.create({
      data: {
        projectId: null,
        type: 'ERROR',
        message: 'Erro durante a execução da simulação',
        details: JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' })
      }
    })

    return NextResponse.json({ 
      error: 'Erro durante a execução da simulação' 
    }, { status: 500 })
  }
}

async function performMassBalanceCalculation(units: any[], streams: any[], projectId: string | null) {
  const results = []
  let totalInputFlow = 0
  let totalOutputFlow = 0

  for (const unit of units) {
    const unitParams = unit.parameters || {}
    
    // Get streams connected to this unit
    const inputStreams = streams.filter(s => s.to === unit.id)
    const outputStreams = streams.filter(s => s.from === unit.id)
    
    const unitInputFlow = inputStreams.reduce((sum, stream) => sum + (stream.flowRate || 0), 0)
    const unitOutputFlow = outputStreams.reduce((sum, stream) => sum + (stream.flowRate || 0), 0)
    
    totalInputFlow += unitInputFlow
    totalOutputFlow += unitOutputFlow

    // Unit-specific calculations
    switch (unit.type) {
      case 'jaw-crusher':
      case 'cone-crusher':
        const crusherEfficiency = unitParams.efficiency || 0.85
        const crusherPower = unitParams.power || 150
        
        results.push({
          unitId: unit.id,
          parameter: 'efficiency',
          value: crusherEfficiency,
          unit: '%'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'power_consumption',
          value: crusherPower,
          unit: 'kW'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'specific_energy',
          value: crusherPower / Math.max(unitInputFlow, 1),
          unit: 'kWh/t'
        })
        break

      case 'ball-mill':
      case 'rod-mill':
      case 'sag-mill':
        const millEfficiency = unitParams.efficiency || 0.90
        const millPower = unitParams.power || 200
        
        results.push({
          unitId: unit.id,
          parameter: 'efficiency',
          value: millEfficiency,
          unit: '%'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'power_consumption',
          value: millPower,
          unit: 'kW'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'specific_energy',
          value: millPower / Math.max(unitInputFlow, 1),
          unit: 'kWh/t'
        })
        break

      case 'hydrocyclone':
        const cycloneEfficiency = unitParams.efficiency || 0.85
        const underflowRatio = 0.6
        const overflowRatio = 0.4
        
        results.push({
          unitId: unit.id,
          parameter: 'efficiency',
          value: cycloneEfficiency,
          unit: '%'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'underflow_flow',
          value: unitInputFlow * underflowRatio,
          unit: 't/h'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'overflow_flow',
          value: unitInputFlow * overflowRatio,
          unit: 't/h'
        })
        break

      case 'flotation-cell':
        const recovery = unitParams.recovery || 0.85
        const concentrateGrade = unitParams.concentrateGrade || 0.65
        const concentrateFlow = unitInputFlow * recovery * concentrateGrade
        const tailingsFlow = unitInputFlow - concentrateFlow
        
        results.push({
          unitId: unit.id,
          parameter: 'recovery',
          value: recovery * 100,
          unit: '%'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'concentrate_grade',
          value: concentrateGrade * 100,
          unit: '%'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'concentrate_flow',
          value: concentrateFlow,
          unit: 't/h'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'tailings_flow',
          value: tailingsFlow,
          unit: 't/h'
        })
        break

      default:
        results.push({
          unitId: unit.id,
          parameter: 'input_flow',
          value: unitInputFlow,
          unit: 't/h'
        })
        
        results.push({
          unitId: unit.id,
          parameter: 'output_flow',
          value: unitOutputFlow,
          unit: 't/h'
        })
    }

    // Mass balance error calculation
    const massBalanceError = Math.abs(unitInputFlow - unitOutputFlow)
    const relativeError = unitInputFlow > 0 ? (massBalanceError / unitInputFlow) * 100 : 0
    
    results.push({
      unitId: unit.id,
      parameter: 'mass_balance_error',
      value: relativeError,
      unit: '%'
    })

    // Log warnings for significant mass balance errors
    if (relativeError > 5) {
      await db.simulationLog.create({
        data: {
          projectId,
          type: 'WARNING',
          message: `Unidade ${unit.name}: Erro de balanço de massa de ${relativeError.toFixed(2)}%`,
          details: JSON.stringify({ unitId: unit.id, error: relativeError })
        }
      })
    }
  }

  // Overall system results
  const overallRecovery = totalInputFlow > 0 ? (totalOutputFlow / totalInputFlow) * 100 : 0
  const overallMassBalanceError = totalInputFlow > 0 ? Math.abs(totalInputFlow - totalOutputFlow) / totalInputFlow * 100 : 0
  
  results.push({
    parameter: 'total_input_flow',
    value: totalInputFlow,
    unit: 't/h'
  })
  
  results.push({
    parameter: 'total_output_flow',
    value: totalOutputFlow,
    unit: 't/h'
  })
  
  results.push({
    parameter: 'overall_recovery',
    value: overallRecovery,
    unit: '%'
  })
  
  results.push({
    parameter: 'overall_mass_balance_error',
    value: overallMassBalanceError,
    unit: '%'
  })

  // Log overall warnings
  if (overallMassBalanceError > 2) {
    await db.simulationLog.create({
      data: {
        projectId,
        type: 'WARNING',
        message: `Erro geral de balanço de massa: ${overallMassBalanceError.toFixed(2)}%`,
        details: JSON.stringify({ overallError: overallMassBalanceError })
      }
    })
  }

  // Save results to database
  for (const result of results) {
    await db.simulationResult.create({
      data: {
        projectId,
        unitOperation: result.unitId,
        parameter: result.parameter,
        value: result.value,
        unit: result.unit
      }
    })
  }

  return results
}