import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '50')
    const offset = parseInt(searchParams.get('offset') || '0')
    const type = searchParams.get('type')
    const projectId = searchParams.get('projectId')

    const whereClause: any = {}
    if (type && type !== 'ALL') {
      whereClause.type = type
    }
    if (projectId) {
      whereClause.projectId = projectId
    }

    const logs = await db.simulationLog.findMany({
      where: whereClause,
      orderBy: {
        timestamp: 'desc'
      },
      take: limit,
      skip: offset
    })

    const totalCount = await db.simulationLog.count({
      where: whereClause
    })

    return NextResponse.json({
      logs,
      totalCount,
      limit,
      offset
    })

  } catch (error) {
    console.error('Error fetching logs:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar logs' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, message, details, projectId } = body

    if (!type || !message) {
      return NextResponse.json(
        { error: 'Tipo e mensagem são obrigatórios' },
        { status: 400 }
      )
    }

    const log = await db.simulationLog.create({
      data: {
        type,
        message,
        details: details ? JSON.stringify(details) : null,
        projectId
      }
    })

    return NextResponse.json(log)

  } catch (error) {
    console.error('Error creating log:', error)
    return NextResponse.json(
      { error: 'Erro ao criar log' },
      { status: 500 }
    )
  }
}